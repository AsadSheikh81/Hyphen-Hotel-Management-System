package com.example.hms.Entities;

public class FeedbackDTO {
    private String feedbackContent;

    // Getters and setters
    public String getFeedbackContent() {
        return feedbackContent;
    }

    public void setFeedbackContent(String feedbackContent) {
        this.feedbackContent = feedbackContent;
    }
}