package com.example.hms.Entities;

public enum BookingStatus {
    PENDING, CONFIRMED, CANCELLED, CHECKED_OUT
}